public class CECS225ExamPolicy {

  public static void main (String [] args) {
  
    System.out.println("Rule #1 - Open book and open notes (physical only)");

    System.out.println();
    
    System.out.println("Rule # 2 - No phones, calculators, or any additional tabs");

    System.out.println();
    
    System.out.println("Rule # 3 - No Talking during the exam!");
    
    System.out.println();

    System.out.println("Rule # 4 - The ONLY tab that you can be is ON BeachBoard (exam page)");

    System.out.println();
    
    System.out.println("Rule # 5 - If ONE of the following rules is violated above, you will be escorted out of the room, a 0 will be given for that exam, and Neal Terrell will be notified!");

    }
    
}
