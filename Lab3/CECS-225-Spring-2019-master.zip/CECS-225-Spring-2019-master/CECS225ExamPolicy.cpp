#include<iostream>
#include<string>

using namespace std;

// C++ currently with Steve Gold
// CECS225ExamPolicy.cpp

int main() {
      
      
      cout << "Rule #1 - Open book and open notes (physical only)" << endl;

      cout << endl;

      cout << "Rule # 2 - No phones, calculators, or any additional tabs" << endl;
      
      cout << endl;

      cout << "Rule # 3 - No Talking during the exam! << endl;
      
      cout << endl;

      cout << "Rule # 4 - The ONLY tab that you can be is ON BeachBoard (exam page)" << endl;
      
      cout << endl;

      cout << "Rule # 4 - If ONE of the following rules is violated above, you will be escorted out of the room, a 0 will be given for that exam, and Neal Terrell will be notified!" << endl;

      getchar();
      getchar();
      getchar();
      

      return 0;
      
    }
