def cecs225QuizAndExamRules():

  print("Rule #1 - Open book and open notes (physical only)")

  print()

  print("Rule # 2 - No phones, calculators, or any additional tabs")

  print()
  
  print("Rule # 3 - No Talking during the exam!")

  print()

  print("Rule # 4 - The ONLY tab that you can be is ON BeachBoard (exam page)")

  print()

  print("Rule # 4 - If ONE of the following rules is violated above, you will be escorted out of the room, a 0 will be given for that exam, and Neal Terrell will be notified!")


def main():

  examPolicy = cecs225QuizAndExamRules()
  
  
main()
