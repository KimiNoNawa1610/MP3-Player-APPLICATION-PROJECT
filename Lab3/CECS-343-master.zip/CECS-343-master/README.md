# CECS-343
#To Do:
/////////////
#1.	Try to look at the getURl file in the Menu class and make it work with all the data. Research how to take sql data and move to java
//////////////////
#2.Add a delete and add button for the Menu class. The add button should trigger the addsong method. And create a method to delete the song from data base- research on goolge
////////////////
#3.Create a new column for the sql data base called URL to store the URL of the song
///////////////
#4. Change the add song method to add the song's URL. 
