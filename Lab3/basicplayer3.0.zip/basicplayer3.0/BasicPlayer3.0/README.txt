---------------------------------------------------------
 jlGui : JAVA music player for Java platform.

 Project Homepage :
   http://www.javazoom.net/jlgui/jlgui.html

 MP3 & JAVA Forums :
   http://www.javazoom.net/services/forums/index.jsp

 JNLP (JavaWebStart) configurator :
   http://www.javazoom.net/jlgui/jnlp_configurator.jsp
---------------------------------------------------------

11/14/2006 : 3.0
----------------
- JavaSound mixer selector added.
- "basicplayer.sourcedataline" property added.
- Skip bug fix.
+ J2SE 1.6.0 RC


04/05/2004 : jlGui - BasicPlayer 2.3
------------------------------------
- Seek feature added.

- BasicPlayer redesigned :
  + BasicPlayerEvent added.
  + Threaded events
  + Audio properties.

- Bug fixes :
  + 8 bits WAV file support added.

- Tested JavaSound SPI :
  + VorbisSPI 1.0 (JavaZOOM).
  + MP3SPI 1.9 (JavaZOOM).
  + WAV, AU, AIFF (SUN)

- Tested J2SE :
  + J2SE 1.3.1
  + J2SE 1.4.2
  + J2SE 1.5.0 beta